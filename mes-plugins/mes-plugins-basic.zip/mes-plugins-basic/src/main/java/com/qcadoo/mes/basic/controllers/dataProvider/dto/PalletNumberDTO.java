package com.qcadoo.mes.basic.controllers.dataProvider.dto;

public class PalletNumberDTO implements AbstractDTO {

    private Long id;

    private String code;

    private String number;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

}
