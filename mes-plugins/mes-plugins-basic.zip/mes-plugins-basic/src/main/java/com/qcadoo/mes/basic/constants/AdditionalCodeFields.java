package com.qcadoo.mes.basic.constants;

public final class AdditionalCodeFields {

    private AdditionalCodeFields() {
    }

    public static final String CODE = "code";

    public static final String PRODUCT = "product";

}
