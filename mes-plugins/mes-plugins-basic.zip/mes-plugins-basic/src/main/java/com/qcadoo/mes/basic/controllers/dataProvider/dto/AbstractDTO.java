package com.qcadoo.mes.basic.controllers.dataProvider.dto;

public interface AbstractDTO {

}
